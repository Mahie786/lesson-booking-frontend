<template>
  <ShoppingCart />
</template>

<script>
import ShoppingCart from "@/components/cart/ShoppingCart.vue";
export default {
  components: { ShoppingCart },
};
</script>
