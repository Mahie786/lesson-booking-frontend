<template>
  <div class="home">
    <h1>Welcome to Lesson Booking</h1>
  </div>
</template>

<script>
export default {
  name: "Home",
};
</script>
